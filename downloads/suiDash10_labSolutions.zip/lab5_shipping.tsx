import React, { useEffect, useState, useMemo } from 'react';

import Map from '@splunk/visualizations/Map';

import { MapContextProvider, testTileConfig } from '@splunk/visualization-context/MapContext';
import WaitSpinner from '@splunk/react-ui/WaitSpinner';
import SearchJob from '@splunk/search-job';
import type { SearchJobRawResults } from '@splunk/search-job';

import { StyledContainer, SectionTitle, VizContainer } from './ShippingStyles';

// --- Type Definitions ---

type MapField = { name: string; type?: string };

// --- End Type Definitions ---

const SEARCH_TIME_RANGE = { earliest_time: "-24h@h", latest_time: "now" };

const Shipping = () => {


    // ==== SEARCHES ====

    const [loadingMap, setLoadingMap] = useState(true);
    const [error, setError] = useState<Error | null>(null);
    const [rawFields, setRawFields] = useState<MapField[]>([]);
    const [rawColumns, setRawColumns] = useState<unknown[][]>([]);
    const [resultCount, setResultCount] = useState(0);

    const safeConfig = useMemo(() => {
        const defaultConfig = {
            url: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
            attribution: '© OpenStreetMap contributors',
            maxZoom: 18,
            minZoom: 1,
            subdomains: ['a', 'b', 'c'],
            zoomConstraints: {
                minZoom: 1,
                maxZoom: 18,
            },
        };
        return testTileConfig || defaultConfig;
    }, []);

    const contextValue = useMemo(
        () => ({
            defaultTileConfig: safeConfig,
        }),
        [safeConfig]
    );



    // ==== Map Search ====

    useEffect(() => {

        let isMounted = true;
        setLoadingMap(true);
        setError(null);

        const mapSearch = SearchJob.create({
            search:
                'index=bccscm sourcetype=scm:logistics vendor=* ' +
                '| eval shipDate=strftime(strptime(shipDate, "%Y-%m-%d"), "%Y-%m") ' +
                '| eval location_info=Roast+", shipDate: "+shipDate ' +
                '| geostats latfield=vendorLatitude longfield=vendorLongitude sum(Amount) by location_info',
            ...SEARCH_TIME_RANGE,
        });

        const subscription = mapSearch.getResults().subscribe({
            next: (results: SearchJobRawResults) => {
                const fields: MapField[] = (results.fields ?? []).map((f) =>
                    typeof f === 'string' ? { name: f } : { name: f.name }
                );

                const rows = (results.results ?? []) as Record<string, unknown>[];
                const fieldNames = fields.map((f) => f.name);

                const columns = fieldNames.map((name) =>
                    rows.map((row) => {
                        const val = row[name];
                        return val ?? null;
                    })
                );

                if (!isMounted) return;
                setRawFields(fields);
                setRawColumns(columns);
                setResultCount(rows.length);
                setLoadingMap(false);
            },
            error: (err: Error) => {
                if (!isMounted) return;
                setError(err);
                setLoadingMap(false);
            },
        });

        return () => {
            isMounted = false;
            subscription.unsubscribe();
        };


    }, []);


    return (
        <StyledContainer>

            {/* ===== VISUALIZATIONS ===== */}

            <SectionTitle>Shipping</SectionTitle>

            {/* ===== VISUALIZATIONS ===== */}
            <VizContainer>
                <MapContextProvider value={contextValue}>
                    {loadingMap ? (
                        <div role="status" aria-live="polite">
                            <WaitSpinner size="medium" />
                            <div>Loading map data...</div>
                        </div>
                    ) : (
                        <>
                            <Map
                                options={{
                                    center: [14.1615, -21.0599],
                                    zoom: 1.2,
                                }}
                                dataSources={{
                                    primary: {
                                        requestParams: {
                                            offset: 0,
                                        },
                                        data: {
                                            fields: rawFields,
                                            columns: rawColumns,
                                        },
                                        meta: {
                                            totalCount: resultCount,
                                            done: true,
                                        },
                                    },
                                }}
                                width="100%"
                                height="600px"
                            />

                            {!resultCount && (
                                <div
                                    style={{
                                        position: 'absolute',
                                        top: '50%',
                                        left: '50%',
                                        transform: 'translate(-50%, -50%)',
                                    }}
                                >
                                    No data available
                                </div>
                            )}
                        </>
                    )}

                    {error && <div>Error loading map data: {error.message || 'Unknown error occurred.'}</div>}
                </MapContextProvider>
            </VizContainer>


        </StyledContainer>
    );
};

export default Shipping;

