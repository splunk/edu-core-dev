import React from 'react';
import { useNavigate } from 'react-router-dom';
import styled, { createGlobalStyle } from 'styled-components';
import { variables } from '@splunk/themes';

import Tabs from '@splunk/tabs';
import Overview from '@splunk/overview';
import Shipping from '@splunk/shipping';

type AppTabId = 'overview';

const GlobalStyle = createGlobalStyle`
  html, body, #root {
    background-color: ${variables.white} !important;
  }
`;

const PageWrap = styled.div`
    padding: 18px 40px;
`;

const Header = styled.div`
    display: flex;
    align-items: flex-start;
    margin-bottom: 8px;
`;

const Logo = styled.img`
    margin: 20px 0 0 0;
    width: 120px;
    height: 101px;
    object-fit: contain;
    margin-left: auto;
`;

const AppTitle = styled.h2`
    margin: 20px 0 0 0;
    font-family: "Splunk Platform Sans", "Proxima Nova", Roboto, Droid, "Helvetica Neue", Helvetica, Arial, sans-serif;
    font-size: 24px;
    font-weight: 600;
`;

const TabsIndent = styled.div`
    margin-left: 10px;
    margin-top: -50px;
`;

const AppShell = () => {

    const navigate = useNavigate();
    const activePanelId: AppTabId = 'overview';


    return (
        <>
            <GlobalStyle />
            <PageWrap>
                <Header>
                    <AppTitle>Buttercup Coffee Supply Chain</AppTitle>
                    <Logo
                        src="/static/app/buttercup-coffee/bccLogo.png"
                        alt="Buttercup Coffee logo"
                    />
                </Header>

                <TabsIndent>
                    <Tabs
                        activePanelId={activePanelId}
                        onChange={(tabId) => navigate(`/${tabId}`)}
                        overviewContent={<Overview />}
                    />
                </TabsIndent>
            </PageWrap>
        </>
    );
};

export default AppShell;
