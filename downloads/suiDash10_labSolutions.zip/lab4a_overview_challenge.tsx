import React, { useState, useEffect, useRef, useMemo } from 'react';

import Column from '@splunk/visualizations/Column';
import WaitSpinner from '@splunk/react-ui/WaitSpinner';

import SingleValue from '@splunk/visualizations/SingleValue';

import Select from '@splunk/react-ui/Select';

import {
    StyledContainer,
    VizContainer,
    SectionTitle,
    Label,
    VizRow,
} from './OverviewStyles'


// --- Type Definitions ---
interface SearchResultField {
    name: string;
}

interface ColumnChartResultRow {
    Country: string;
    KilosPurchased: number;
}

interface SplunkSearchResults<T> {
    fields: SearchResultField[];
    results: T[];
}

type RawResults = {
    fields?: Array<string | { name: string }>;
    results?: Array<Record<string, unknown>>;
};

type AnyRow = Record<string, unknown>;


// --- End Type Definitions ---

const SearchJob = require('@splunk/search-job').default;

const normalizeFields = (rawFields?: Array<string | { name: string }>): SearchResultField[] => {
    if (!rawFields) {
        return [];
    }
    return rawFields.map(field => {
        if (typeof field === 'string') {
            return { name: field };
        }
        return field;
    });
};

const SEARCH_TIME_RANGE = { earliest_time: "-24h@h", latest_time: "now" };

const Overview = () => {

    // ==== SEARCHES ====


    // ===== Dropdown Search =====

    useEffect(() => {
        const job = SearchJob.create({
            search: '| inputlookup purchasesByCountry | fields Country | dedup Country | sort Country',
            earliest_time: '0',
            latest_time: 'now',
        });

        const sub = job.getResults({ count: 1000 }).subscribe({
            next: (raw: RawResults) => {
                const values = (raw.results || [])
                    .map((r: any) => String(r.Country ?? '').trim())
                    .filter((v) => v.length > 0);

                setCountryOptions(values);
            },
            error: (err: Error) => {
                console.error('Error loading countries:', err);
                setCountryOptions([]);
            },
        });

        return () => {
            sub.unsubscribe();
            job.cancel?.();
        };
    }, []);



    // Dropdown State
    const [countryToken, setCountryToken] = useState('*');
    const [countryOptions, setCountryOptions] = useState<string[]>([]);

    const normalizedCountry = useMemo(() => countryToken.trim() || '*', [countryToken]);

    // Change Handler 
    const handleCountryChange = (_event: React.SyntheticEvent, { value }: { value: string | number | boolean }) => {
        setCountryToken(String(value));
    };


    // Single Value Search Tokens

    const countryFilter = useMemo(() => {
        const escapedCountry = normalizedCountry
            .replace(/\\/g, '\\\\')
            .replace(/"/g, '\\"');

        return normalizedCountry === '*'
            ? ''
            : ` | search Country="${escapedCountry}"`;
    }, [normalizedCountry]);



    // Single Value Data State
    const [KiloBags, setKiloBags] = useState(0);
    const [KilosPurchased, setKilosPurchased] = useState(0);
    const [ShippingCosts, setShippingCosts] = useState(0);

    const [loadingKiloBags, setLoadingKiloBags] = useState(true);
    const [loadingKilosPurchased, setLoadingKilosPurchased] = useState(true);
    const [loadingShippingCosts, setLoadingShippingCosts] = useState(true);

    // ==== Single Value 1 Search - Kilos Purchased ====
    useEffect(() => {
        // Reset loading when country changes
        setLoadingKilosPurchased(true);

        // Apply the countryFilter to the search
        const sv1Search = SearchJob.create({
            search: `index=bccscm sourcetype=scm:logistics ${countryFilter} | stats sum(Amount) as KilosPurchased`.replace(/\s+/g, ' ').trim(),
            ...SEARCH_TIME_RANGE,
        });



        const subscription = sv1Search.getResults().subscribe({
            next: (results: RawResults) => {
                if (results?.results?.length) {
                    const latestDataPoint = results.results[results.results.length - 1];
                    setKilosPurchased(Number((latestDataPoint as any).KilosPurchased) || 0);
                } else {
                    setKilosPurchased(0);
                }
                setLoadingKilosPurchased(false);
            },
            error: (err: unknown) => {
                setKilosPurchased(0);
                setLoadingKilosPurchased(false);
            },
        });

        return () => {
            subscription.unsubscribe();
            // Cancel job on cleanup
            sv1Search.cancel?.();
        };
        // Rerun when the shared filter changes
    }, [countryFilter]);


    // ==== Single Value 2 Search – Total Bags ====
    useEffect(() => {
        // Reset loading when country changes
        setLoadingKiloBags(true);

        const sv2Search = SearchJob.create({
            // Apply shared countryFilter to the search
            search: `index=bccscm ${countryFilter} | stats sum(Amount) as KiloBags | eval KiloBags=round(KiloBags/70,2) `.replace(/\s+/g, ' ').trim(),
            ...SEARCH_TIME_RANGE,
        });


        const subscription = sv2Search.getResults().subscribe({
            next: (results: RawResults) => {
                if (results?.results?.length) {
                    const latestDataPoint = results.results[results.results.length - 1];
                    setKiloBags(Number((latestDataPoint as any).KiloBags) || 0);
                } else {
                    setKiloBags(0);
                }
                setLoadingKiloBags(false);
            },

            error: (err: unknown) => {
                setKiloBags(0);
                setLoadingKiloBags(false);
            },
        });

        return () => {
            subscription.unsubscribe();
            // Cancel job on cleanup
            sv2Search.cancel?.();
        };
        // Rerun when the shared filter changes
    }, [countryFilter]);


    // ==== Single Value 3 Search – Shipping Costs ====
    useEffect(() => {
        // Reset loading when country changes
        setLoadingShippingCosts(true);

        const sv3Search = SearchJob.create({
            // Apply shared countryFilter to the search
            search: `index=bccscm sourcetype=scm:logistics ${countryFilter} | stats sum(shipCost) as ShippingCosts`.replace(/\s+/g, ' ').trim(),
            ...SEARCH_TIME_RANGE,
        });

        const subscription = sv3Search.getResults().subscribe({
            next: (results: RawResults) => {
                if (results?.results?.length) {
                    const latestDataPoint = results.results[results.results.length - 1];
                    setShippingCosts(Number((latestDataPoint as any).ShippingCosts) || 0);

                } else {
                    setShippingCosts(0);
                }
                setLoadingShippingCosts(false);
            },
            error: (err: unknown) => {
                setShippingCosts(0);
                setLoadingShippingCosts(false);
            },
        });

        return () => {
            subscription.unsubscribe();
            // Cancel job on cleanup
            sv3Search.cancel?.();
        };
        // Rerun when the shared filter changes
    }, [countryFilter]);




    // Column Chart Data State
    const [columnChartResults, setColumnChartResults] = useState<SplunkSearchResults<ColumnChartResultRow>>({ fields: [], results: [] });
    const [loadingColumnChart, setLoadingColumnChart] = useState(true);

    const columnMeasureRef = useRef<HTMLDivElement | null>(null);
    const [columnWidth, setColumnWidth] = useState(0);
    const safeColumnWidth = Math.max(400, columnWidth);

    const vizData = useMemo(() => ({
        fields: ['Country', 'KilosPurchased'],
        columns: [
            columnChartResults.results.map((r) => r.Country),
            columnChartResults.results.map((r) => r.KilosPurchased),
        ],
    }), [columnChartResults]);


    useEffect(() => {
        const observers: Array<ResizeObserver> = [];
        const observeElement = (el: HTMLDivElement | null, setter: (w: number) => void) => {
            if (!el) return;
            const ro = new ResizeObserver((entries) => {
                for (const entry of entries) {
                    const w = Math.floor(entry.contentRect.width);
                    setter(w);
                }
            });
            ro.observe(el);
            observers.push(ro);
            setter(Math.floor(el.clientWidth));
        };

        observeElement(columnMeasureRef.current, setColumnWidth);

        return () => {
            observers.forEach((ro) => {
                ro.disconnect();
            });
        };
    }, []);


    // ==== Column Chart Search ====

    useEffect(() => {

        setLoadingColumnChart(true);

        const filter =
            countryToken === '*'
                ? ''
                : `| search Country="${countryToken.replace(/"/g, '\\"')}"`;

        const columnChartSearch = SearchJob.create({
            search: `index=bccscm sourcetype=scm:logistics ${filter} | chart sum(Amount) as KilosPurchased over Country`,
            ...SEARCH_TIME_RANGE,
        });

        if (typeof (columnChartSearch as any).start === 'function') {
            (columnChartSearch as any).start();
        }
        const subscription = columnChartSearch.getResults().subscribe({
            next: (raw: unknown) => {
                const rawResults = raw as RawResults;
                if (rawResults && Array.isArray(rawResults.results)) {
                    const normalizedFields = normalizeFields(rawResults.fields);
                    const mappedResults: SplunkSearchResults<ColumnChartResultRow> = {
                        fields: normalizedFields,
                        results: rawResults.results.map((r) => ({
                            Country: String(r?.Country ?? ''),
                            KilosPurchased: Number(
                                (r?.KilosPurchased as number | string | undefined) ?? 0
                            ),
                        })),
                    };
                    setColumnChartResults(mappedResults);
                } else {
                    setColumnChartResults({ fields: [], results: [] });
                }
                setLoadingColumnChart(false);
            },
            error: (err: unknown) => {
                console.error('Error fetching column chart results:', err);
                setColumnChartResults({ fields: [], results: [] });
                setLoadingColumnChart(false);
            },
        });

        return () => {
            subscription?.unsubscribe();
            (columnChartSearch as any)?.cancel?.();
        };


    }, [countryToken]);


    return (
        <StyledContainer>

            {/* ===== VISUALIZATIONS ===== */}

            <SectionTitle>Overview</SectionTitle>

            {/* ===== Dropdown Input ===== */}

            <Label>Select a Country:</Label>
            <Select
                value={countryToken}
                onChange={handleCountryChange}
                style={{ width: 150, marginBottom: 16 }}
            >
                <Select.Option label="All Countries" value="*" />
                {countryOptions.map((c) => (
                    <Select.Option key={c} label={c} value={c} />
                ))}
            </Select>

            <VizRow>
                <VizContainer style={{ flex: 1, minWidth: 0 }}>
                    {/* ===== SV 1 Viz Total Kilos Purchased ===== */}
                    <Label>Kilos Purchased</Label>

                    <SingleValue
                        mode="view"
                        width={300}
                        height={100}
                        context={{
                            majorColorThresholds: [
                                { from: 0, value: '#118832' },
                                { to: 0, value: '#D41F1F' },
                            ],
                        }}
                        options={{
                            majorFontSize: 58,
                            unit: 'kg',
                            unitPosition: 'after',
                            unitFontSize: 12,
                            majorValue: KilosPurchased,
                            underLabel: 'Last 24 hours',
                            underLabelFontSize: 14,

                        }}
                        dataSources={{
                            primary: {
                                requestParams: {},
                                meta: {},
                                data: {
                                    fields: [{ name: 'KilosPurchased' }],
                                    columns: [[KilosPurchased]],
                                },
                            },
                        }}
                        style={{ height: '100px' }}
                    />
                </VizContainer>
                <VizContainer style={{ flex: 1, minWidth: 0 }}>

                    {/* ===== SV 2 Viz Total Bags Shipped ===== */}
                    <Label>Total Bags (70kg) Shipped</Label>
                    <SingleValue
                        mode="view"
                        width={300}
                        height={100}
                        context={{
                            majorColorThresholds: [
                                { from: 0, value: '#118832' },
                                { to: 0, value: '#D41F1F' },
                            ],
                        }}
                        options={{
                            majorFontSize: 58,
                            majorValue: KiloBags,
                            underLabel: 'Last 24 hours',
                            underLabelFontSize: 14,
                        }}
                        dataSources={{
                            primary: {
                                requestParams: {},
                                meta: {},
                                data: {
                                    fields: [{ name: 'KiloBags' }],
                                    columns: [[KiloBags]],
                                },
                            },
                        }}
                        style={{ height: '100px' }}
                    />
                </VizContainer>
                <VizContainer style={{ flex: 1, minWidth: 0 }}>

                    {/* ===== SV 3 Viz Shipping Costs ===== */}
                    <Label>Shipping Costs</Label>
                    <SingleValue
                        mode="view"
                        width={300}
                        height={100}
                        context={{
                            majorColorThresholds: [
                                { from: 0, value: "#118832" },
                                { to: 0, value: "#D41F1F" },
                            ],
                        }}
                        options={{
                            majorFontSize: 58,
                            unit: "$",
                            unitPosition: "before",
                            majorValue: ShippingCosts,
                            underLabel: "Last 24 hours",
                            underLabelFontSize: 14,
                        }}
                        dataSources={{
                            primary: {
                                requestParams: {},
                                meta: {},
                                data: {
                                    fields: [{ name: "ShippingCosts" }],
                                    columns: [[ShippingCosts]],
                                },
                            },
                        }}
                        style={{ height: "100px" }}
                    />
                </VizContainer>
            </VizRow>

            <VizRow>

                {/* ===== Column Chart ===== */}
                <VizContainer style={{ flex: 1, minWidth: 0 }}>
                    <div ref={columnMeasureRef} style={{ width: '100%' }}>
                        <Label>Coffee Shipments</Label>
                        {loadingColumnChart ? (
                            <WaitSpinner size="medium" />
                        ) : (
                            <Column
                                mode="view"
                                width={safeColumnWidth}
                                height={400}
                                options={{
                                    title: 'Sales by Country',
                                    yAxisTitleVisibility: 'hide',
                                    xAxisTitleVisibility: 'hide',
                                    legendDisplay: 'bottom',
                                }}
                                dataSources={{
                                    primary: {
                                        requestParams: {},
                                        meta: {},
                                        data: vizData,
                                    },
                                }}
                            />
                        )}
                    </div>
                </VizContainer>

            </VizRow>


        </StyledContainer>
    );
};

export default Overview;
