import React from 'react';
import styled from 'styled-components';
import TabLayout from '@splunk/react-ui/TabLayout';
import House from '@splunk/react-icons/House';
import Ship from '@splunk/react-icons/Ship';

type AppTabId = 'overview' | 'shipping';

type Props = {
    activePanelId: AppTabId;
    onChange: (tabId: AppTabId) => void;
    overviewContent: React.ReactNode;
    shippingContent: React.ReactNode;
};

const TabsWrapper = styled.div`
    [role='tabpanel'] {
        padding-top: 0 !important;
        margin-top: 0 !important;
    }
`;

const Tabs = ({ activePanelId, onChange, overviewContent, shippingContent }: Props) => (
    <TabsWrapper>
        <TabLayout
            layout="vertical"
            activePanelId={activePanelId}
            onChange={(e, { activePanelId: nextId }) => onChange(nextId as AppTabId)}
        >
            <TabLayout.Panel panelId="overview" label="Overview" icon={<House />}>
                {overviewContent}
            </TabLayout.Panel>

            <TabLayout.Panel panelId="shipping" label="Shipping" icon={<Ship />}>
                {shippingContent}
            </TabLayout.Panel>


        </TabLayout>
    </TabsWrapper>
);

export default Tabs;