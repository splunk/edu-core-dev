#!/bin/bash

URL="https://localhost:8089"

curl -k -X GET $URL \
-H "Authorization: Bearer $TOKEN" \
| xmlstarlet sel -N atom="http://www.w3.org/2005/Atom" -t \
-m /atom:feed/atom:entry -v 'atom:title' -n