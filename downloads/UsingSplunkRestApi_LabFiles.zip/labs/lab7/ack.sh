#!/bin/bash

URL="https://localhost:8088"

curl -k -X POST $URL \
-H "Authorization: Splunk {hec token}" \
-H "X-Splunk-Request-Channel: {GUID}" \
-d '{"acks":[]}'

echo ""