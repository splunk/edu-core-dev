#!/bin/bash

URL="https://localhost:8089"

curl -k -X POST $URL \
-H "Authorization: Bearer $TOKEN" \
-H "Content-Type: application/json" \
--data-binary "@employees.json"

echo ""