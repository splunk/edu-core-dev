import os
import requests
import urllib3
import xml.etree.ElementTree as ET

# suppress HTTPS warning messages
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# REST API endpoint
url = "https://localhost:8089"

# Headers to send with the request (a JSON object)
headers = {
        'Authorization': 'Bearer ' + os.environ['TOKEN'],
        'Content-Type': 'application/x-www-form-urlencoded'
}

# invoke the REST API
response = requests.get(url=url, headers=headers, verify=False)

# retrieve and print response data
print(response.content)