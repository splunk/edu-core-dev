#!/bin/bash

URL="https://localhost:8089"

curl -k -X GET $URL \
-H "Authorization: Bearer $TOKEN"
