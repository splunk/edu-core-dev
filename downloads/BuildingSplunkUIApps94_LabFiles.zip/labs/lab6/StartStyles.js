import { createGlobalStyle } from 'styled-components';
import { variables } from '@splunk/themes';

const GlobalStyles = createGlobalStyle`
    body {
        background-color: ${variables.backgroundColorPage};
    }
`;

export { GlobalStyles };
