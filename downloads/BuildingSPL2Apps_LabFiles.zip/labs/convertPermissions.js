const fs = require('fs');

(async function() {

    // PUT request data
    let data = {
        "resourceType": "module",
        "resourceName": input[0].resourceName,
        "permissions": [
            { "operation": "execute", "roles": [] },
            { "operation": "read", "roles": [] },
            { "operation": "write", "roles": [] }
        ]
    };

    // read the GET response
    const inFile = fs.readFileSync('response.json');
    const input = JSON.parse(inFile);

    // migrate data from GET to PUT
    input.forEach(item => {
        item.operations.forEach(op => {
            const perm = data.permissions.find(obj => obj.operation === op);
            perm.roles.push(item.role);
        });
    });

    // write the PUT request
    const output = JSON.stringify(data, null, 2);
    fs.writeFileSync('request.json', output);

})().catch(err => console.log(err));