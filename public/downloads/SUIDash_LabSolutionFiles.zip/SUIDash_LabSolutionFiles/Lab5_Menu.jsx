import React from 'react';
import TabLayout from '@splunk/react-ui/TabLayout';
import House from '@splunk/react-icons/House';
import Table from '@splunk/react-icons/Table';
import Ship from '@splunk/react-icons/Ship';
import Overview from '@splunk/overview';
import Inventory from '@splunk/inventory';

import { StyledContainer, StyledSidebar } from './MenuStyles';

const Menu = () => {
    
return (
    <StyledContainer>
        <StyledSidebar>

            <TabLayout defaultActivePanelId="overview" layout="vertical">

              <TabLayout.Panel label="Overview" panelId="overview" icon={<House />}>
              <Overview />
              </TabLayout.Panel>

              <TabLayout.Panel label="Inventory" panelId="inventory" icon={<Table />}>
              <Inventory />
              </TabLayout.Panel>

              <TabLayout.Panel label="Shipping" panelId="shipping" icon={<Ship />}>
                <p>SHIPPING Placeholder</p>
              </TabLayout.Panel>

            </TabLayout>

      </StyledSidebar>

    </StyledContainer>
  );
};

export default Menu;
