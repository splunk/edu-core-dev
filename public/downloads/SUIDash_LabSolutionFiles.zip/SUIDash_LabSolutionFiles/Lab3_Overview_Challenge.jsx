import React, { useState, useEffect } from 'react';
import SearchJob from '@splunk/search-job';
import Column from '@splunk/visualizations/Column';
import Bar from '@splunk/visualizations/Bar';
import WaitSpinner from '@splunk/react-ui/WaitSpinner';
import ColumnLayout from '@splunk/react-ui/ColumnLayout';
import SingleValue from '@splunk/visualizations/SingleValue';


import { StyledContainer, sectionTitle, labelStyle, colStyle, columnRowStyles } from './OverviewStyles';

const Overview = () => {
  const SEARCH_TIME_RANGE = { earliest_time: "-24h@h", latest_time: "now" };
  const [columnChartResults, setColumnChartResults] = useState({ fields: [], results: [] });
  const [loadingColumnChart, setLoadingColumnChart] = useState(true);
 
  const [barChartResults, setBarChartResults] = useState({ fields: [], results: [] });
  const [loadingBarChart, setLoadingBarChart] = useState(true);

  const [KiloBags, setKiloBags] = useState(0);
  const [KilosPurchased, setKilosPurchased] = useState(0);
  const [ShippingCosts, setShippingCosts] = useState(0);
 
  const [loadingKiloBags, setLoadingKiloBags] = useState(true);
  const [loadingKilosPurchased, setLoadingKilosPurchased] = useState(true);
  const [loadingShippingCosts, setLoadingShippingCosts] = useState(true); 

// ==== SEARCHES ====

// ==== Single Value 1 Search - Kilos Purchased ====
useEffect(() => {
  const sv1Search = SearchJob.create({
      search: `index=bccscm | stats sum(Amount) as KilosPurchased`,
      ...SEARCH_TIME_RANGE,
  });

  const subscription = sv1Search.getResults().subscribe({
      next: (results) => {
          console.log("KilosPurchased data received:", results);
  setKilosPurchased(Number(results?.results?.[0]?.KilosPurchased) || 0);

          if (results?.results?.length) {
 const latestDataPoint = results.results[results.results.length - 1];
        setKilosPurchased(Number(latestDataPoint?.KilosPurchased) || 0);
          } else {
              setKiloBags(0);
          }
          setLoadingKilosPurchased(false);
      },
      error: (err) => {
          console.error("Error fetching KilosPurchased results:", err);
          setKilosPurchased(0);
          setLoadingKilosPurchased(false);
      },
  });

return () => {
      subscription.unsubscribe();
  };
}, []);


// ==== Single Value 2 Search – Total Bags ====
useEffect(() => {
  const sv2Search = SearchJob.create({
    search: `index=bccscm | stats sum(Amount) as KiloBags | eval KiloBags=round(KiloBags/70,2)`,
    ...SEARCH_TIME_RANGE,
  });

  const subscription = sv2Search.getResults().subscribe({
    next: (results) => {
      console.log("KiloBags data received:", results);
  
      if (results?.results?.length) {
  const latestDataPoint = results.results[results.results.length - 1];
        setKiloBags(Number(latestDataPoint?.KiloBags) || 0);  
        
      } else {
        setKiloBags(0);
      }
  
      setLoadingKiloBags(false);
    },

    error: (err) => {
      console.error("Error fetching KiloBags results:", err);
      setKiloBags(0);
      setLoadingKiloBags(false);
    },
  });

  return () => subscription.unsubscribe();
}, []);

// ==== Single Value 3 Search – Shipping Costs ====
useEffect(() => {
  const sv3Search = SearchJob.create({
    search: `index=bccscm | stats sum(shipCost) as ShippingCosts`,
    ...SEARCH_TIME_RANGE,
  });

  const subscription = sv3Search.getResults().subscribe({
    next: (results) => {
      console.log("ShippingCosts data received:", results);

      if (results?.results?.length) {
        const latestDataPoint = results.results[results.results.length - 1];
        setShippingCosts(Number(latestDataPoint?.ShippingCosts) || 0);
       
      } else {
        setShippingCosts(0);
      }
      setLoadingShippingCosts(false);
    },
    error: (err) => {
      console.error("Error fetching Shipping Costs results:", err);
      setShippingCosts(0);
      setLoadingShippingCosts(false);
    },
  });

  return () => subscription.unsubscribe();
}, []);


// ==== Bar Chart Search ====

useEffect(() => {
  setLoadingBarChart(true);
  const barChartSearch = SearchJob.create({
   search: `index=bccscm | chart count(inventory) AS Inventory by warehouse, Roast`,
       ...SEARCH_TIME_RANGE
   });
       
  const subscription = barChartSearch.getResults().subscribe({
   next: (results) => {
       if (results && results.results) {	
           setBarChartResults(results);
         } else {
           setBarChartResults({ fields: [], results: [] });
         }
         setLoadingBarChart(false);
         },  
   error: (err) => {
       console.error("Error fetching bar chart results:", err);
         setBarChartResults({ fields: [], results: [] });
         setLoadingBarChart(false);
   },
  }); 
  return () => {
     if (subscription) {
         subscription.unsubscribe();
     }
     if (barChartSearch) {
         barChartSearch.cancel(); 
     }
  };
 
},[]);  


// ==== Column Chart Search ====

useEffect(() => {

  setLoadingColumnChart(true);
 const columnChartSearch = SearchJob.create({
    search: `index=bccscm | chart sum(Amount) AS KilosPurchased by Country`,
      ...SEARCH_TIME_RANGE
  });
      
 const subscription = columnChartSearch.getResults().subscribe({
  next: (results) => {
      if (results && results.results) {
          setColumnChartResults(results);
        } else {
          setColumnChartResults({ fields: [], results: [] });
        }
        setLoadingColumnChart(false);
        },  
  error: (err) => {
      console.error("Error fetching column chart results:", err);
      setColumnChartResults({ fields: [], results: [] });
      setLoadingColumnChart(false);
  },
 }); 
 return () => {
    if (subscription) {
        subscription.unsubscribe();
    }
    if (columnChartSearch) {
        columnChartSearch.cancel(); 
    }
 };


},[]); 

    
// ==== VISUALIZATIONS ====

return (
  <StyledContainer>
 
    <h1 style={sectionTitle}>Overview</h1>

    <ColumnLayout gutter={8}>
      <ColumnLayout.Row style={columnRowStyles}>
        <ColumnLayout.Column span={4} style={colStyle}>

          {/* ===== SV 1 Viz Total Kilos Purchased ===== */}
          <p style={labelStyle}>Kilos Purchased</p>

          <SingleValue
              height={100}
              context={{
                  majorColorThresholds: [
                    { from: 0, value: '#118832' }, 
                    { to: 0, value: '#D41F1F' },  
                  ],
              }}
              options={{
                  majorFontSize: 58, 
                  unit: 'kg',
                  unitPosition: 'after',
                  unitFontSize: 12,
                  majorValue: KilosPurchased,
                  underLabel: 'Last 24 hours',
                  underLabelFontSize: 14,

              }}
              dataSources={{
                  primary: {
                    data: {
                        fields: [{ name: 'KilosPurchased' }],
                        columns: [[KilosPurchased]], 
                    },
                  },
              }}
              style={{ height: '100px' }}
          />

          </ColumnLayout.Column>

          <ColumnLayout.Column span={4} style={colStyle}>

{/* ===== SV 2 Viz Total Bags Shipped ===== */}
   <p style={labelStyle}>Total Bags (70kg) Shipped</p>
    <SingleValue
     height={100}
     context={{
      majorColorThresholds: [
        { from: 0, value: '#118832' }, 
        { to: 0, value: '#D41F1F' },  
      ],
     }}
      options={{
       majorFontSize: 58, 
       majorValue: KiloBags,
       underLabel: 'Last 24 hours',
       underLabelFontSize: 14,
      }}
      dataSources={{
       primary: {
        data: {
          fields: [{ name: 'KiloBags' }],
          columns: [[KiloBags]], 
        },
      },
    }}
    style={{ height: '100px' }}
  />

 </ColumnLayout.Column>

 <ColumnLayout.Column span={4} style={colStyle}>

{/* ===== SV 3 Viz Shipping Costs ===== */}
<p style={labelStyle}>Shipping Costs</p>
  <SingleValue
    height={100}
    context={{
      majorColorThresholds: [
        { from: 0, value: "#118832" },
        { to: 0, value: "#D41F1F" },
      ],
    }}
    options={{
      majorFontSize: 58,
        unit: "$",
        unitPosition: "before",
        majorValue: ShippingCosts,
        underLabel: "Last 24 hours",
        underLabelFontSize: 14,
      }}
      dataSources={{
        primary: {
         data: {
          fields: [{ name: "ShippingCosts" }],
          columns: [[ShippingCosts]],
         },
        },
      }}
      style={{ height: "100px" }}
    />
</ColumnLayout.Column>
</ColumnLayout.Row>

<ColumnLayout.Row style={columnRowStyles}>
  <ColumnLayout.Column span={6} style={colStyle}>

     {/* ===== Column Chart ===== */}
      <div>
      <h2 style={labelStyle}>Coffee Shipments</h2>
       {loadingColumnChart ? (
      <WaitSpinner size="medium" label="Loading column chart data..." />
       ) : (
       <Column
        options={{
         title: 'Sales by Country',
         yAxisTitleVisibility: 'hide',
         xAxisTitleVisibility: 'hide',
         legendDisplay: 'bottom',
        }}
        dataSources={{
         primary: {
          data: {
           fields: ['Country', 'KilosPurchased'],
            columns: 
             columnChartResults.results?.length > 0 ? [
             columnChartResults.results.map((result) => result.Country),
          columnChartResults.results.map((result) => result.KilosPurchased),
            ] : [[], []],
              }   
             }
           }}
          />
        )}
      </div>

      </ColumnLayout.Column>
    <ColumnLayout.Column span={6} style={colStyle}>


 {/* ===== Bar Chart ===== */}

      <div>

      <h2 style={labelStyle}>Stock Available</h2>
      {loadingBarChart ? (
        <WaitSpinner size="medium" label="Loading bar chart data..." />
        ) : (
        <Bar
          options={{
            title: 'Roasts by Location',
            legendDisplay: 'bottom',                
          }}
          dataSources={{
            primary: {
            data: {
            fields: [
              {
                name: 'warehouse',
              },
              {
                name: 'Arabica',
              },
              {
                name: 'Excelsa',
              },
              {
                name: 'Robusta',
              }
            ],
            columns: 
                barChartResults.results?.length > 0 ? [
                barChartResults.results.map((result) => result.warehouse),
        barChartResults.results.map((result) => parseFloat(result.Arabica) || 0),
        barChartResults.results.map((result) => parseFloat(result.Excelsa) || 0),
        barChartResults.results.map((result) => parseFloat(result.Robusta) || 0),
                ] : [[], [], [], []],
          }   
        }
        }}
      />
      )}
      </div>

            </ColumnLayout.Column>
          </ColumnLayout.Row>
        </ColumnLayout>

    
    </StyledContainer>
  );
};

export default Overview;
