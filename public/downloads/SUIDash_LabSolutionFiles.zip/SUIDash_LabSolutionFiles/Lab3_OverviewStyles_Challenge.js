import styled from 'styled-components';
import { variables, mixins } from '@splunk/themes';

const StyledContainer = styled.div`
  ${mixins.reset('inline')};
  display: block;
  font-size: ${variables.fontSizeLarge};
  flex-direction: row;
  margin: ${variables.spacingLarge};
  width: 80vw;
  height: 30vw;
`;

const sectionTitle = {
    fontSize: '24px',
};

const labelStyle = {
    margin: '0',
    fontWeight: 'bold',
    fontSize: '14px',
};
const colStyle = {
    border: '1px solid #d3d3d3',
    padding: 10,
    minHeight: 80,
};

const columnRowStyles = {
    display: 'flex',
    alignItems: 'flex-start', 
    justifyContent: 'space-between',
    flexWrap: 'nowrap',
    display: 'flex',
    height: '150px',
};

export {
    StyledContainer,
    sectionTitle,
    labelStyle,
    colStyle,
    columnRowStyles,
};
