import styled from 'styled-components';
import { variables, mixins } from '@splunk/themes';

const StyledContainer = styled.div`
    ${mixins.reset('inline')};
    display: block;
    font-size: ${variables.fontSizeLarge};
    margin: ${variables.spacingLarge};
`;

const vizContainer = {
      flex: '1', 
      border: '1px solid #d3d3d3', 
      overflowX: 'auto',
      width: '1200px', 
      height: '600px', 
      position: 'relative',
};

const sectionTitle = {
    fontSize: '24px',
};

export {
    StyledContainer, 
    vizContainer, 
    sectionTitle,
};
