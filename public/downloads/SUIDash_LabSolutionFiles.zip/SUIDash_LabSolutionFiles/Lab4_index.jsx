import React from 'react';

import layout from '@splunk/react-page/18';
import Inventory from '@splunk/inventory';
import { getUserTheme } from '@splunk/splunk-utils/themes';

import { StyledContainer } from './StartStyles';

getUserTheme()
    .then((theme) => {
        layout(
            <StyledContainer>
              <Inventory />
            </StyledContainer>,
            {
                theme,
            }
        );
    })
    .catch((e) => {
        const errorEl = document.createElement('span');
        errorEl.innerHTML = e;
        document.body.appendChild(errorEl);
    });
