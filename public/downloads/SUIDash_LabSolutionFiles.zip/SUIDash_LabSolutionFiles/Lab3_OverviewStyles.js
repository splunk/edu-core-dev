import styled from 'styled-components';
import { variables, mixins } from '@splunk/themes';

const StyledContainer = styled.div`
  ${mixins.reset('inline')};
  display: block;
  font-size: ${variables.fontSizeLarge};
  flex-direction: row;
  margin: ${variables.spacingLarge};
  width: 80vw;
`;

const sectionTitle = {
    fontSize: '24px',
};

const vizContainer = {
    flex: '1', 
    height: '100%',
    width: '100%',
    border: '1px solid #d3d3d3', 
    borderRadius: '4px', 
    padding: '10px', 
    overflowX: 'auto',
};

const labelStyle = {
    margin: '0',
    fontWeight: 'bold',
    fontSize: '14px',
};

const vizRowStyle = {
    display: 'flex',
    height: '100%', 
    gap: '20px', 
    marginBottom: '20px',
  };

export { 
    StyledContainer,
    sectionTitle,
    vizContainer, 
    labelStyle, 
    vizRowStyle, 
 };

