import React, { useMemo, useState, useEffect } from 'react';
import Map from '@splunk/visualizations/Map';
import { MapContextProvider, testTileConfig } from '@splunk/visualization-context/MapContext';
import SearchJob from '@splunk/search-job';
import WaitSpinner from '@splunk/react-ui/WaitSpinner';

import { StyledContainer, vizContainer, sectionTitle } from './ShippingStyles';

const Shipping = () => {
    const SEARCH_TIME_RANGE = { earliest_time: "-24h@h", latest_time: "now" };
    const [mapResults, setMapResults] = useState({ fields: [], results: [] });
    const [loadingMap, setLoadingMap] = useState(true);
    const [error, setError] = useState(null);

  const safeConfig = useMemo(() => {
    const defaultConfig = {
        url: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
        attribution: '© OpenStreetMap contributors',
        maxZoom: 18,
        minZoom: 1,
        subdomains: ['a', 'b', 'c'],
        zoomConstraints: {
            minZoom: 1,
            maxZoom: 18
        }
    };
    const config = testTileConfig || defaultConfig;
    if (!config.zoomConstraints) {
        config.zoomConstraints = {
            minZoom: config.minZoom || 1,
            maxZoom: config.maxZoom || 18
        };
    }
    return config;
  }, []);

  const contextValue = useMemo(() => ({
    defaultTileConfig: safeConfig,
    ...(testTileConfig && { testTileConfig })
}), [safeConfig]);

// ==== SEARCH ====

// ==== Map Search ====
useEffect(() => {
  setLoadingMap(true);
   setError(null);
  
   const mapSearch = SearchJob.create({
    search: `index=bccscm sourcetype=scm:logistics vendor=* | eval shipDate=strftime(strptime(shipDate, "%Y-%m-%d"), "%Y-%m") | eval location_info="Vendor: "+vendor+", Roast: "+Roast+", shipDate: "+shipDate | geostats latfield=vendorLatitude longfield=vendorLongitude sum(Amount) by location_info`,
     ...SEARCH_TIME_RANGE,
   });
    
   const subscription = mapSearch.getResults().subscribe({
    next: (results) => {
      console.log('Search results:', results); 
      setMapResults(results); 
      setLoadingMap(false); 
    },
    error: (err) => {
      console.error('Error fetching map results:', err); // Debug: log errors
      setError(err); 
      setLoadingMap(false); 
    },   
  });
    
   return () => subscription.unsubscribe();
}, []);

    const transformDataForMap = (results) => {
      if (!results?.results?.length || !results?.fields?.length) {
        return {
        fields: [],
        columns: []
        };
      }

      const fieldNames = results.fields.map(field => field.name);
      const columns = fieldNames.map(fieldName => {
      const field = results.fields.find(f => f.name === fieldName);
            return results.results.map(row => {
            const value = row[fieldName];
            if (field?.type === 'number' && !['lat', 'lon', 'Latitude', 'Longitude', '_geo'].includes(fieldName)) {
            return formatNumber(value);
            }
            return value;
        });
      });
          
      return {
        fields: results.fields,
        columns: columns
        };
      };

const transformedData = useMemo(() => transformDataForMap(mapResults), [mapResults]);

return (

    <StyledContainer>
       
       {/* ===== Map ===== */}

        <h1 style={sectionTitle}>Shipments</h1>

        <div style={vizContainer}>

        <MapContextProvider value={contextValue}>
          {loadingMap ? (
          <WaitSpinner size="medium" label="Loading map data..." />
          ) : (
          <>
          <Map
            options={{
            center: [14.1615, -21.0599],
            zoom: 1,
            layers: [
              { type: 'bubble',
              latitudeField: 'lat', 
              longitudeField: 'lon',
        valueField: transformedData.fields?.find(f => 
            f.type === 'number' && !['lat', 'lon', 'Latitude', 'Longitude'].includes(f.name)
              )?.name || 'count',
              seriesColors: ['#008000', '#800080', '#FF6B35'],
              opacity: 0.8,
              tooltip: {
                enabled: true,
                excludeFields: ['lat', 'lon', 'Latitude', 'Longitude', '_lat', '_lon']
                }
              },
            ],
            showLegend: true,
            showTooltip: true,
            tooltip: {
              enabled: true,
              excludeFields: ['lat', 'lon', 'Latitude', 'Longitude', '_lat', '_lon']
            }
            }}
            dataSources={{
              primary: {
                requestParams: { 
                offset: 0, 
                search: 'index=bccscm sourcetype=scm:logistics vendor=* | eval shipDate=strftime(strptime(shipDate, "%Y-%m-%d"), "%Y-%m") | eval location_info="Vendor: "+vendor+", Roast: "+Roast+", shipDate: "+shipDate | geostats latfield=vendorLatitude longfield=vendorLongitude sum(Amount) by location_info'
                },
                data: {
                  fields: transformedData.fields || [], 
                  columns: transformedData.columns || [], 
                },
                meta: { 
                  totalCount: mapResults.results?.length || 0,
                  done: true 
                },
              },
            }}
            width="100%"	
            height="100%"
          />
          {(!mapResults?.results?.length) && (
            <div style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)' }}>
                No data available - check console for search results
          </div> )}
        </>
        )}
        {error && (
          <div>
            Error loading map data: {error.message || 'Unknown error occurred.'}
          </div>
        )}

      </MapContextProvider>
        </div>

    </StyledContainer>

  );
};

export default Shipping;
