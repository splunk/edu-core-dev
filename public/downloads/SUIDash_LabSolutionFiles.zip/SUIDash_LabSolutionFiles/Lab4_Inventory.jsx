import React, { useState, useEffect } from 'react';
import Table from '@splunk/react-ui/Table';
import Paginator from '@splunk/react-ui/Paginator';
import Dropdown from '@splunk/react-ui/Dropdown';
import Button from '@splunk/react-ui/Button';
import Menu from '@splunk/react-ui/Menu';
import SearchJob from '@splunk/search-job';
import WaitSpinner from '@splunk/react-ui/WaitSpinner';

import { 
  StyledContainer, 
  sectionTitle, 
  vizContainer, 
  labelStyle,  
  dropdownButtonStyle,
  menuItemStyle,
  arrowStyle
 } from './InventoryStyles';


const Inventory = () => {
  const SEARCH_TIME_RANGE = { earliest_time: "-7d@d", latest_time: "now" };
  const [tableResults, setTableResults] = useState({ fields: [], results: [] });  
  const [loadingTable, setLoadingTable] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const rowsPerPage = 11;
  const handlePageChange = (e, { page }) => {
    setCurrentPage(page); 
  };
  const startIndex = (currentPage - 1) * rowsPerPage;
  const displayedRows = tableResults.results.slice(startIndex, startIndex + rowsPerPage);
  const [countryToken, setCountryToken] = useState('*');
const [displayCountry, setDisplayCountry] = useState('All Countries');
const [dropdownOptions, setDropdownOptions] = useState(['All Countries']);
const [loadingDropdown, setLoadingDropdown] = useState(false);
const handleMenuItemClick = (label) => {
    if (label === 'All Countries') {
      setCountryToken('*');
      setDisplayCountry('All Countries');
    } else {
      setCountryToken(label);
      setDisplayCountry(label);
    }
 };


// ==== SEARCHES ====

// ===== Dropdown Search =====
useEffect(() => {
  setLoadingDropdown(true);

  const dropdownSearch = SearchJob.create({
    search: `| inputlookup purchasesByCountry | fields Country`,
    ...SEARCH_TIME_RANGE
  });

  const subscription = dropdownSearch.getResults().subscribe({
    next: (results) => {
      if (results && results.results && results.fields) {
         const countries = results.results.map(result => result.Country || 'Unknown');
         setDropdownOptions(['All Countries', ...countries]);
    } else {
        setDropdownOptions(['All Countries']);
    }
    setLoadingDropdown(false);
  },
  error: (err) => {
    console.error("Error fetching data:", err, "with countryToken:", countryToken || "Not provided");
    setDropdownOptions(['All Countries']);
    setTotalSystemCount(0);
    setLoadingDropdown(false);
  },
 });

  return () => {
    if (subscription) {
        subscription.unsubscribe();
    }
};
}, [countryToken]);



// ==== Table Search ====

useEffect(() => {

  setLoadingTable(true);

  const tableSearch = SearchJob.create({
   search: `index=bccscm | search Country="${countryToken}" | table orderNo, Country, Roast, schedule, shipDate, deliveryDate, Amount, warehouse`,
    ...SEARCH_TIME_RANGE,
    });

  const subscription = tableSearch.getResults().subscribe({
   next: (results) => {
     if (results?.results?.length && results?.fields?.length) {
         setTableResults(results);
     } else {
         setTableResults({ fields: [], results: [] });
     }
     setLoadingTable(false);
     },
     error: (err) => {
       console.error("Error fetching results:", err);
       setTableResults({ fields: [], results: [] });
       setLoadingTable(false);
      },
   });

   return () => {
       subscription.unsubscribe();
   };

},[countryToken]);

// ==== VISUALIZATIONS ====
    
return (

    <StyledContainer>

      <h1 style={sectionTitle}>Inventory</h1>
      {/* ===== Dropdown Input ===== */}
 <p style={labelStyle}>Select a Country:</p>
     {loadingDropdown ? (
     <WaitSpinner size="small" label="Loading dropdown data..." />
 ) : (
        <Dropdown 
         toggle={
          <Button style={dropdownButtonStyle}>
            {displayCountry}
            <span style={arrowStyle}></span>
          </Button>
        }>
        <Menu style={{ width: 270 }}>
          {dropdownOptions.map((country, index) => (
          <Menu.Item key={index} onClick={() => handleMenuItemClick(country)}
          style={menuItemStyle}>{country}</Menu.Item>
          ))}
         </Menu>
       </Dropdown>
     )} 
     <p />


   {/* ===== Table ===== */}
   <div style={vizContainer}>
   <h2 style={labelStyle}>Coffee Shipments: {displayCountry}</h2>
   {loadingTable ? (
     <WaitSpinner size="medium" label="Loading dropdown data..." />
    ) : tableResults?.fields?.length && tableResults?.results?.length ? (
     <>
      <Table stripeRows>
        <Table.Head>
          <Table.HeadCell>Order No.</Table.HeadCell>
          <Table.HeadCell>Country</Table.HeadCell>
          <Table.HeadCell>Roast</Table.HeadCell>
          <Table.HeadCell>Schedule</Table.HeadCell>
          <Table.HeadCell>Ship Date</Table.HeadCell>
          <Table.HeadCell>Delivery Date</Table.HeadCell>
          <Table.HeadCell>Amount (kg)</Table.HeadCell>
          <Table.HeadCell>Warehouse</Table.HeadCell>
        </Table.Head>
        <Table.Body>
         {displayedRows.map((result, rowIndex) => (
            <Table.Row key={rowIndex}>
              {tableResults.fields?.map((field) => (
               <Table.Cell key={`${rowIndex}-${field.name}`}>
                    {result[field.name] || "N/A"}
               </Table.Cell>
              ))}
           </Table.Row>
         ))}
        </Table.Body>
      </Table>
      {tableResults.results.length > 0 && (

      <Paginator
          current={currentPage}
            totalPages={Math.max(1, Math.ceil(tableResults.results.length / rowsPerPage))}
          onChange={handlePageChange}
        />

      )}

     </>
   ) : (
   <div>No table data available.</div>
  )}
  </div>

    </StyledContainer>
  );
};

export default Inventory;
