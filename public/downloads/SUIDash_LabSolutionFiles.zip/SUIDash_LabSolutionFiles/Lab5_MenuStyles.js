import styled from 'styled-components';
import { variables, mixins } from '@splunk/themes';

const StyledContainer = styled.div`
    ${mixins.reset('inline')};
    display: flex;
    flex-direction: column;
    font-size: ${variables.fontSizeLarge};
`;

const StyledSidebar = styled.div`
    width: 150px;
    background: #ffffff; 
`;

export { 
  StyledContainer, 
  StyledSidebar
};
