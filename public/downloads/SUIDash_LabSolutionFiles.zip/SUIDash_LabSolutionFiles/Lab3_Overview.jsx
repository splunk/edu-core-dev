import React, { useState, useEffect } from 'react';
import SearchJob from '@splunk/search-job';
import Column from '@splunk/visualizations/Column';
import Bar from '@splunk/visualizations/Bar';
import WaitSpinner from '@splunk/react-ui/WaitSpinner';

import { StyledContainer, vizContainer, sectionTitle, labelStyle, vizRowStyle } from './OverviewStyles';

const Overview = () => {
  const SEARCH_TIME_RANGE = { earliest_time: "-24h@h", latest_time: "now" };
  const [columnChartResults, setColumnChartResults] = useState({ fields: [], results: [] });
  const [loadingColumnChart, setLoadingColumnChart] = useState(true);
 
  const [barChartResults, setBarChartResults] = useState({ fields: [], results: [] });
  const [loadingBarChart, setLoadingBarChart] = useState(true);

// ==== SEARCHES ====

// ==== Bar Chart Search ====

useEffect(() => {
  setLoadingBarChart(true);
  const barChartSearch = SearchJob.create({
   search: `index=bccscm | chart count(inventory) AS Inventory by warehouse, Roast`,
       ...SEARCH_TIME_RANGE
   });
       
  const subscription = barChartSearch.getResults().subscribe({
   next: (results) => {
       if (results && results.results) {  
           setBarChartResults(results);
         } else {
           setBarChartResults({ fields: [], results: [] });
         }
         setLoadingBarChart(false);
         },  
   error: (err) => {
       console.error("Error fetching bar chart results:", err);
         setBarChartResults({ fields: [], results: [] });
         setLoadingBarChart(false);
   },
  }); 
  return () => {
     if (subscription) {
         subscription.unsubscribe();
     }
     if (barChartSearch) {
         barChartSearch.cancel(); 
     }
  };
 
},[]);  


// ==== Column Chart Search ====

useEffect(() => {

  setLoadingColumnChart(true);
 const columnChartSearch = SearchJob.create({
    search: `index=bccscm | chart sum(Amount) AS KilosPurchased by Country`,
      ...SEARCH_TIME_RANGE
  });
      
 const subscription = columnChartSearch.getResults().subscribe({
  next: (results) => {
      if (results && results.results) {
          setColumnChartResults(results);
        } else {
          setColumnChartResults({ fields: [], results: [] });
        }
        setLoadingColumnChart(false);
        },  
  error: (err) => {
      console.error("Error fetching column chart results:", err);
      setColumnChartResults({ fields: [], results: [] });
      setLoadingColumnChart(false);
  },
 }); 
 return () => {
    if (subscription) {
        subscription.unsubscribe();
    }
    if (columnChartSearch) {
        columnChartSearch.cancel(); 
    }
 };


},[]); 

    
// ==== VISUALIZATIONS ====

return (
  <StyledContainer>
 
    <h1 style={sectionTitle}>Overview</h1>
    <div style={vizRowStyle}>
 
     {/* ===== Column Chart ===== */}
      <div style={vizContainer}>
      <h2 style={labelStyle}>Coffee Shipments</h2>
       {loadingColumnChart ? (
      <WaitSpinner size="medium" label="Loading column chart data..." />
       ) : (
       <Column
        options={{
         title: 'Sales by Country',
         yAxisTitleVisibility: 'hide',
         xAxisTitleVisibility: 'hide',
         legendDisplay: 'bottom',
        }}
        dataSources={{
         primary: {
          data: {
           fields: ['Country', 'KilosPurchased'],
            columns: 
             columnChartResults.results?.length > 0 ? [
             columnChartResults.results.map((result) => result.Country),
          columnChartResults.results.map((result) => result.KilosPurchased),
            ] : [[], []],
              }   
             }
           }}
          />
        )}
      </div>
 {/* ===== Bar Chart ===== */}

 <div style={vizContainer}>

<h2 style={labelStyle}>Stock Available</h2>
 {loadingBarChart ? (
  <WaitSpinner size="medium" label="Loading bar chart data..." />
  ) : (
   <Bar
    options={{
      title: 'Roasts by Location',
      legendDisplay: 'bottom',                
     }}
    dataSources={{
      primary: {
      data: {
       fields: [
        {
          name: 'warehouse',
        },
        {
          name: 'Arabica',
        },
        {
          name: 'Excelsa',
        },
        {
          name: 'Robusta',
        }
       ],
       columns: 
          barChartResults.results?.length > 0 ? [
          barChartResults.results.map((result) => result.warehouse),
   barChartResults.results.map((result) => parseFloat(result.Arabica) || 0),
   barChartResults.results.map((result) => parseFloat(result.Excelsa) || 0),
   barChartResults.results.map((result) => parseFloat(result.Robusta) || 0),
          ] : [[], [], [], []],
     }   
   }
  }}
/>
)}
</div>
</div>
    
    </StyledContainer>
  );
};

export default Overview;
