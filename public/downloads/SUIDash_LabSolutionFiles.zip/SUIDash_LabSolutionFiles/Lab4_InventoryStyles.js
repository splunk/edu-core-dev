import styled from 'styled-components';
import { variables, mixins } from '@splunk/themes';

const StyledContainer = styled.div`
  ${mixins.reset('inline')};
  display: block;
  font-size: ${variables.fontSizeLarge};
  flex-direction: row;
  margin: ${variables.spacingLarge};
  width: 80vw;
  height: 40vw;
`;

const sectionTitle = {
    fontSize: '24px',
};

const vizContainer = {
    flex: '1', 
    border: '1px solid #d3d3d3', 
    borderRadius: '4px', 
    padding: '10px', 
    overflowX: 'auto',
};

const labelStyle = {
    margin: '0',
    fontWeight: 'bold',
    fontSize: '14px',
};
const dropdownButtonStyle = {
    width: '170px',
    textAlign: 'left',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    position: 'relative',
    paddingRight: '30px'
  };
  
  const arrowStyle = {
    position: 'absolute',
    right: '10px',
    top: '50%',
    width: '0',
    height: '0',
    borderLeft: '6px solid transparent',
    borderRight: '6px solid transparent',
    borderTop: '6px solid black',
    pointerEvents: 'none',
    transform: 'translateY(-50%)'
  };
  
  const menuItemStyle = {
    textAlign: 'left'
  };
  
  export { 
    StyledContainer, 
    sectionTitle, 
    vizContainer, 
    labelStyle, 
    dropdownButtonStyle, 
    arrowStyle, 
    menuItemStyle 
};
  
