#!/bin/bash

echo -e "\nCreating saved searches...\n"

uri=(
        "services/saved/searches"
        "servicesNS/restclient/search/saved/searches"
        "servicesNS/neil/rest_app/saved/searches"
)

for i in "${!uri[@]}"; do
        curl -k -s -o /dev/null -w "  [%{http_code}] ${uri[$i]}\n" \
        -X POST "https://localhost:8089/${uri[$i]}" \
        -H "Authorization: Bearer $TOKEN" \
        --data-urlencode "name=Saved_Search_${i}" \
        --data-urlencode "search=index=_internal" \
        --data-urlencode "dispatch.earliest_time=-1h@h" \
        --data-urlencode "dispatch.latest_time=now"
done

echo -e "\nDone!\n"
