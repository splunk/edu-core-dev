// suppress warning messages
process.removeAllListeners('warning');
// allow self-signed certificates
process.env.NODE_TLS_REJECT_UNAUTHORIZED = 0;

(async function() {

        // REST API endpoint
        const url = "https://localhost:8089";

        // Headers to send with the request (a JSON object)
        const headers = new Headers({
                'Authorization': 'Bearer ' + process.env.TOKEN,
                'Content-Type': 'application/x-www-form-urlencoded'
        });

        // invoke the REST API
        const response = await fetch(url, {'method':'get', 'headers':headers});

        // retrieve and print response data
        let data = await response.json();
        console.log(data);

})().catch(err => console.log(err));