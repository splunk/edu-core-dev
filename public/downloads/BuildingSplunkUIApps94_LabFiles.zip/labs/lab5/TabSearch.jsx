import React, { useState } from 'react';
import JSONTree from '@splunk/react-ui/JSONTree';
import StaticContent from '@splunk/react-ui/StaticContent';

import SearchBar from '@splunk/react-search/components/Bar';
import searchBNF from "@splunk/dashboard-utils/defaultSPLSyntax.json";

import SearchJob from '@splunk/search-job';
import * as config from '@splunk/splunk-utils/config';

const TabSearch = () => {
    const [options, setOptions] = useState({
        "earliest": "-7d@d",
        "latest": "now",
        "search": "index=bcg_sales sourcetype=sales:web",
        "syntax": searchBNF
    });
    const [fields, setFields] = useState([]);
    const [events, setEvents] = useState([]);
    const [status, setStatus] = useState("");
    const [duration, setDuration] = useState("");

    const handleOptionsChange = (option) => {
        console.log(option);
        setOptions({...options, ...option});
    };
    
    const handleEventTrigger = (e) => {
        const job = SearchJob.create({
            search: options.search,
            earliest_time: options.earliest,
            latest_time: options.latest
        }, {
            app: config.app,
            owner: config.username
        });
        
        const progress = job.getProgress().subscribe({
            next: searchState => {
                console.log("\njob.getProgress.next");
                console.log(searchState);

                setStatus(searchState.content.dispatchState);
                setDuration(searchState.content.runDuration);        
            },
            error: err => {
                console.log(err);
            },
            complete: () => {
                console.log("\njob.getProgress.complete!");
            }
        });

        const results = job.getResults().subscribe({
            next: response => {
                console.log("\njob.getResults.next");
                console.log(response);

                setFields(response.fields);
                setEvents(response.results);
            },
            error: err => {
                console.log(err);
            },
            complete: () => {
                console.log("\njob.getResults.complete!");
            }
        });    
    };
    
    return (<div style={{ margin: 25 }}>
        <SearchBar
            options={options}
            onOptionsChange={handleOptionsChange}
            onEventTrigger={handleEventTrigger}
        />
        <StaticContent>Status: {status} {duration}</StaticContent>
        <StaticContent>Fields</StaticContent>
        <JSONTree json={fields} expandChildrenOnShiftKey />
        <StaticContent>Events</StaticContent>
        <JSONTree json={events} expandChildrenOnShiftKey />
    </div>);
};

export default TabSearch;
