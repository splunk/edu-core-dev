import React, { useState } from 'react';
import StaticContent from '@splunk/react-ui/StaticContent';
import Table from '@splunk/react-ui/Table';

import SearchBar from '@splunk/react-search/components/Bar';
import searchBNF from "@splunk/dashboard-utils/defaultSPLSyntax.json";

import SearchJob from '@splunk/search-job';
import * as config from '@splunk/splunk-utils/config';

const TabSearch = () => {
    const [options, setOptions] = useState({
        "earliest": "-7d@d",
        "latest": "now",
        "search": "index=bcg_sales sourcetype=sales:web",
        "syntax": searchBNF
    });
    const [fields, setFields] = useState([]);
    const [events, setEvents] = useState([]);
    const [status, setStatus] = useState("");
    const [duration, setDuration] = useState("");

    const handleOptionsChange = (option) => {
        console.log(option);
        setOptions({...options, ...option});
    };
    
    const handleEventTrigger = (e) => {
        const job = SearchJob.create({
            search: options.search,
            earliest_time: options.earliest,
            latest_time: options.latest
        }, {
            app: config.app,
            owner: config.username
        });
        
        const progress = job.getProgress().subscribe({
            next: searchState => {
                console.log("\njob.getProgress.next");
                console.log(searchState);

                setStatus(searchState.content.dispatchState);
                setDuration(searchState.content.runDuration);        
            },
            error: err => {
                console.log(err);
            },
            complete: () => {
                console.log("\njob.getProgress.complete!");
            }
        });

        const results = job.getResults().subscribe({
            next: response => {
                console.log("\njob.getResults.next");
                console.log(response);

                let filtered = response.fields.filter(f => !f.name.startsWith("_"));
                filtered.push({"name": "_raw"});

                setFields(filtered);
                setEvents(response.results);
            },
            error: err => {
                console.log(err);
            },
            complete: () => {
                console.log("\njob.getResults.complete!");
            }
        });    
    };
    
    return (<div style={{ margin: 25 }}>
        <SearchBar
            options={options}
            onOptionsChange={handleOptionsChange}
            onEventTrigger={handleEventTrigger}
        />
        <StaticContent>Status: {status} {duration}</StaticContent>
        <Table>
            <Table.Head>
                {fields.map((field,i) => (
                    <Table.HeadCell key={'f'+i}>{field.name}</Table.HeadCell>
                ))}
            </Table.Head>
            <Table.Body>
                {events.map((event,i) => (
                    <Table.Row key={'r'+i}>
                        {fields.map((field,ii) => (
                            <Table.Cell key={'c'+ii}>{event[field.name]}</Table.Cell>
                        ))}   
                    </Table.Row>
                ))}
            </Table.Body>
        </Table>
    </div>);
};

export default TabSearch;
