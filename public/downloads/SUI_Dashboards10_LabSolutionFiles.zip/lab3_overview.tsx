import React, { useState, useEffect, useRef, useMemo } from 'react';
import Column from '@splunk/visualizations/Column';
import WaitSpinner from '@splunk/react-ui/WaitSpinner';

import Bar from '@splunk/visualizations/Bar';

import {
    StyledContainer,
    VizContainer,
    SectionTitle,
    Label,
    VizRow,
} from './OverviewStyles'


// --- Type Definitions ---

interface BarChartResultRow {
    warehouse: string;
    Arabica: number;
    Excelsa: number;
    Robusta: number;
    [key: string]: string | number;
}

interface SearchResultField {
    name: string;
}

interface ColumnChartResultRow {
    Country: string;
    KilosPurchased: number;
}

interface SplunkSearchResults<T> {
    fields: SearchResultField[];
    results: T[];
}

type RawResults = {
    fields?: Array<string | { name: string }>;
    results?: Array<Record<string, unknown>>;
};

type AnyRow = Record<string, unknown>;

// --- End Type Definitions ---

const SearchJob = require('@splunk/search-job').default;

const normalizeFields = (rawFields?: Array<string | { name: string }>): SearchResultField[] => {
    if (!rawFields) {
        return [];
    }
    return rawFields.map(field => {
        if (typeof field === 'string') {
            return { name: field };
        }
        return field;
    });
};

const SEARCH_TIME_RANGE = { earliest_time: "-24h@h", latest_time: "now" };

const Overview = () => {

    // ==== SEARCHES ====

    // Bar Chart Data State
    const [barChartResults, setBarChartResults] = useState<SplunkSearchResults<BarChartResultRow>>({ fields: [], results: [] });
    const [loadingBarChart, setLoadingBarChart] = useState(true);

    const barMeasureRef = useRef<HTMLDivElement | null>(null);
    const [barWidth, setBarWidth] = useState(0);
    const safeBarWidth = Math.max(400, barWidth);


    // Column Chart Data State
    const [columnChartResults, setColumnChartResults] = useState<SplunkSearchResults<ColumnChartResultRow>>({ fields: [], results: [] });
    const [loadingColumnChart, setLoadingColumnChart] = useState(true);

    const columnMeasureRef = useRef<HTMLDivElement | null>(null);
    const [columnWidth, setColumnWidth] = useState(0);
    const safeColumnWidth = Math.max(400, columnWidth);

    const vizData = useMemo(() => ({
        fields: ['Country', 'KilosPurchased'],
        columns: [
            columnChartResults.results.map((r) => r.Country),
            columnChartResults.results.map((r) => r.KilosPurchased),
        ],
    }), [columnChartResults]);

    useEffect(() => {
        const observers: Array<ResizeObserver> = [];
        const observeElement = (el: HTMLDivElement | null, setter: (w: number) => void) => {
            if (!el) return;
            const ro = new ResizeObserver((entries) => {
                for (const entry of entries) {
                    const w = Math.floor(entry.contentRect.width);
                    setter(w);
                }
            });
            ro.observe(el);
            observers.push(ro);
            setter(Math.floor(el.clientWidth));
        };

        observeElement(columnMeasureRef.current, setColumnWidth);
        observeElement(barMeasureRef.current, setBarWidth);

        return () => {
            observers.forEach((ro) => {
                ro.disconnect();
            });
        };
    }, []);

    // ==== Bar Chart Search ====

    useEffect(() => {


        setLoadingBarChart(true);
        const barChartSearch = SearchJob.create({
            search:
                `index=bccscm sourcetype=scm:logistics | chart count(inventory) over warehouse by Roast`,
            ...SEARCH_TIME_RANGE,

        });
        if (typeof (barChartSearch as any).start === 'function') {
            (barChartSearch as any).start();
        }
        const subscription = barChartSearch.getResults().subscribe({
            next: (raw: unknown) => {
                const rawResults = raw as RawResults;
                if (rawResults && Array.isArray(rawResults.results)) {
                    const normalizedFields = normalizeFields(rawResults.fields);
                    const mappedResults: SplunkSearchResults<BarChartResultRow> = {
                        fields: normalizedFields,
                        results: rawResults.results.map((r) => ({
                            warehouse: String(r?.warehouse ?? r?.Warehouse ?? ''),
                            Arabica: Number(r?.Arabica ?? 0),
                            Excelsa: Number(r?.Excelsa ?? 0),
                            Robusta: Number(r?.Robusta ?? 0),
                        })),
                    };
                    setBarChartResults(mappedResults);
                } else {
                    setBarChartResults({ fields: [], results: [] });
                }
                setLoadingBarChart(false);
            },
            error: (err: unknown) => {
                console.error('Error fetching bar chart results:', err);
                setBarChartResults({ fields: [], results: [] });
                setLoadingBarChart(false);
            },
        });

        return () => {
            subscription?.unsubscribe();
            (barChartSearch as any)?.cancel?.();
        };

    }, []);

    const barFieldNames = barChartResults.fields.map((f) => f.name).filter(Boolean);
    const warehouseField = barFieldNames.find((n) => n.toLowerCase() === 'warehouse') || 'warehouse';
    const barSeriesFields = barFieldNames.filter((n) => n.toLowerCase() !== warehouseField.toLowerCase() && n.toLowerCase() !== 'roast'
    );


    // ==== Column Chart Search ====

    useEffect(() => {

        setLoadingColumnChart(true);
        const columnChartSearch = SearchJob.create({
            search:
                'index=bccscm sourcetype=scm:logistics | chart sum(Amount) as KilosPurchased over Country',
            ...SEARCH_TIME_RANGE,
        });
        if (typeof (columnChartSearch as any).start === 'function') {
            (columnChartSearch as any).start();
        }
        const subscription = columnChartSearch.getResults().subscribe({
            next: (raw: unknown) => {
                const rawResults = raw as RawResults;
                if (rawResults && Array.isArray(rawResults.results)) {
                    const normalizedFields = normalizeFields(rawResults.fields);
                    const mappedResults: SplunkSearchResults<ColumnChartResultRow> = {
                        fields: normalizedFields,
                        results: rawResults.results.map((r) => ({
                            Country: String(r?.Country ?? ''),
                            KilosPurchased: Number(
                                (r?.KilosPurchased as number | string | undefined) ?? 0
                            ),
                        })),
                    };
                    setColumnChartResults(mappedResults);
                } else {
                    setColumnChartResults({ fields: [], results: [] });
                }
                setLoadingColumnChart(false);
            },
            error: (err: unknown) => {
                console.error('Error fetching column chart results:', err);
                setColumnChartResults({ fields: [], results: [] });
                setLoadingColumnChart(false);
            },
        });

        return () => {
            subscription?.unsubscribe();
            (columnChartSearch as any)?.cancel?.();
        };


    }, []);


    return (
        <StyledContainer>

            {/* ===== VISUALIZATIONS ===== */}

            <SectionTitle>Overview</SectionTitle>

            <VizRow>

                {/* ===== Column Chart ===== */}
                <VizContainer style={{ flex: 1, minWidth: 0 }}>
                    <div ref={columnMeasureRef} style={{ width: '100%' }}>
                        <Label>Coffee Shipments</Label>
                        {loadingColumnChart ? (
                            <WaitSpinner size="medium" />
                        ) : (
                            <Column
                                mode="view"
                                width={safeColumnWidth}
                                height={400}
                                options={{
                                    title: 'Sales by Country',
                                    yAxisTitleVisibility: 'hide',
                                    xAxisTitleVisibility: 'hide',
                                    legendDisplay: 'bottom',
                                }}
                                dataSources={{
                                    primary: {
                                        requestParams: {},
                                        meta: {},
                                        data: vizData,
                                    },
                                }}
                            />
                        )}
                    </div>
                </VizContainer>

                {/* ===== Bar Chart ===== */}
                <VizContainer style={{ flex: 1, minWidth: 0 }}>
                    <div ref={barMeasureRef} style={{ width: '100%' }}>
                        <Label>Stock Available</Label>
                        {loadingBarChart ? (
                            <WaitSpinner size="medium" />
                        ) : (
                            <Bar
                                mode="view"
                                width={safeBarWidth}
                                height={400}
                                options={{
                                    title: 'Roasts by Location',
                                    legendDisplay: 'bottom',
                                    xAxisTitleVisibility: 'hide',
                                    yAxisTitleVisibility: 'hide',
                                }}
                                dataSources={{
                                    primary: {
                                        requestParams: {},
                                        meta: {},
                                        data: {
                                            fields: [warehouseField, ...barSeriesFields],
                                            columns:
                                                barChartResults.results?.length > 0
                                                    ? [
                                                        barChartResults.results.map((r) =>
                                                            String(r.warehouse)
                                                        ),
                                                        ...barSeriesFields.map((sf) =>
                                                            barChartResults.results.map((r) =>
                                                                Number(r[sf])
                                                            )
                                                        )
                                                    ]
                                                    : [[], ...barSeriesFields.map(() => [])]
                                        },
                                    },
                                }}
                            />
                        )}
                    </div>
                </VizContainer>


            </VizRow>


        </StyledContainer>
    );
};

export default Overview;
