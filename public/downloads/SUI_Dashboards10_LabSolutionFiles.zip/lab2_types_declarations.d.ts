declare module '@splunk/search-job' {
    export interface SearchJobOptions {
        search: string;
        earliest_time?: string;
        latest_time?: string;
        [key: string]: any;
    }

    export interface SearchJobRawResults {
        fields?: (string | { name: string })[];
        results?: Record<string, any>[];
    }

    export interface Subscription {
        unsubscribe(): void;
    }

    export interface ProgressStream {
        subscribe(observer: (data: any) => void): Subscription;
    }

    export interface SearchJobResults {
        subscribe(observer: {
            next: (results: SearchJobRawResults) => void;
            error: (error: Error) => void;
        }): Subscription;
    }

    export interface SearchJobInstance {
        getProgress(): ProgressStream;
        getResults(options?: { count?: number; offset?: number }): SearchJobResults;               
        cancel?(): void;
    }

    const SearchJob: {
        create(options: SearchJobOptions): SearchJobInstance;
    };

    export default SearchJob;
}

declare module '@splunk/visualization-context*' {
    import { ReactNode, Context, FC } from 'react';

    export interface VisualizationContextValue {
        mode: 'view' | 'edit' | 'preview';
        width: number;
        height: number;
        status: string;
        [key: string]: any;
    }

    export const VisualizationContext: Context<VisualizationContextValue>;

    export interface VisualizationContextProviderProps {
        value: Partial<VisualizationContextValue>;
        children: ReactNode;
    }

    export const VisualizationContextProvider: FC<VisualizationContextProviderProps>;
}
