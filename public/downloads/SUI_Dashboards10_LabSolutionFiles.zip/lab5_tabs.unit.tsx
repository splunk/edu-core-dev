import React from 'react';
import { render } from '@testing-library/react';
import Tabs from '../Tabs';

describe('Tabs', () => {
    const defaultProps = {
        activePanelId: 'overview' as const,
        onChange: jest.fn(),
        overviewContent: <div>Overview content</div>,
        inventoryContent: <div>Inventory content</div>,
        shippingContent: <div>Shipping content</div>,
    };

    it('renders', () => {
        render(<Tabs {...defaultProps} />);
    });
});
