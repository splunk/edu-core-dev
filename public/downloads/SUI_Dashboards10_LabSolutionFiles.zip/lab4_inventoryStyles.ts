import styled from 'styled-components';
import { variables, mixins } from '@splunk/themes';

export const StyledContainer = styled.div`
        ${mixins.reset('inline')};
        display: block;
        font-size: ${variables.fontSizeLarge};
        flex-direction: row;
        margin: ${variables.spacingLarge};
        width: 80vw;
        padding-top: 0 !important;
        padding-left: 40px;
`;

export const SectionTitle = styled.h2`
        font-size: 24px;
        margin: 10; 
`;

export const VizContainer = styled.div`
        flex: 1;
        height: 100%;
        width: 100%;
        border: 1px solid #d3d3d3;
        border-radius: 4px;
        padding: 10px;
        overflow-x: auto;
`;

export const Label = styled.p`
        margin: 0;
        font-weight: bold;
        font-size: 14px;
`;

export const VizRow = styled.div`
        display: flex; 
        height: 100%; 
        gap: 20px; 
        margin-bottom: 20px;
        flex-direction: column;
        gap: 16px; 
        width: 100%; 
`;

export const PaginatorWrapper = styled.div`
        width: 100%; 
        display: flex;
        justify-content: flex-start; 
`;

export const containerStyle = styled.div`
        width: 100%;
        height: auto;
        overflow-x: hidden;
`;
