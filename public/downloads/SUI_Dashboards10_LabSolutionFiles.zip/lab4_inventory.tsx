import React, { useState, useEffect, useMemo } from 'react';

import WaitSpinner from '@splunk/react-ui/WaitSpinner';
import Table from '@splunk/react-ui/Table';
import Paginator from '@splunk/react-ui/Paginator';

import Select from '@splunk/react-ui/Select';

import {
    StyledContainer,
    VizContainer,
    SectionTitle,
    Label,
    VizRow,
} from './InventoryStyles'


// --- Type Definitions ---
type RawResults = {
    fields?: Array<string | { name: string }>;
    results?: Array<Record<string, unknown>>;
};

type SearchResultRow = Record<string, unknown>;

interface SearchResultField {
    name: string;
}

interface InventoryTableState {
    fields: SearchResultField[];
    results: SearchResultRow[];
}

// --- End Type Definitions ---

const SearchJob = require('@splunk/search-job').default;

const normalizeFields = (rawFields?: Array<string | { name: string }>): SearchResultField[] => {
    if (!rawFields) {
        return [];
    }
    return rawFields.map(field => {
        if (typeof field === 'string') {
            return { name: field };
        }
        return field;
    });
};

const SEARCH_TIME_RANGE = { earliest_time: "-24h@h", latest_time: "now" };

const Inventory = () => {

    // ==== SEARCHES ====

    // Dropdown state
    const [countryToken, setCountryToken] = useState('*');
    const [countryOptions, setCountryOptions] = useState<string[]>([]);

    const normalizedCountry = useMemo(() => countryToken.trim() || '*', [countryToken]);

    // Table Data State
    const [tableResults, setTableResults] = useState<InventoryTableState>({ fields: [], results: [] });
    const [loadingTable, setLoadingTable] = useState(true);
    const [activeJob, setActiveJob] = useState<any>(null);

    // Pagination State
    const [totalResults, setTotalResults] = useState(0);
    const [currentPage, setCurrentPage] = useState(1);
    const rowsPerPage = 11;

    // Event Handlers
    const handlePageChange = (_event: React.SyntheticEvent, data: { page: number }) => {
        setCurrentPage(data.page);
    };

    const handleCountryChange = (_event: React.SyntheticEvent, { value }: { value: string | number | boolean }) => {
        setCountryToken(String(value));
        setCurrentPage(1);
    };

    // ===== Dropdown Search =====

    useEffect(() => {
        const job = SearchJob.create({
            search: '| inputlookup purchasesByCountry | fields Country | dedup Country | sort Country',
            earliest_time: '0',
            latest_time: 'now',
        });

        const sub = job.getResults({ count: 1000 }).subscribe({
            next: (raw: RawResults) => {
                const values = (raw.results || [])
                    .map((r: any) => String(r.Country ?? '').trim())
                    .filter((v) => v.length > 0);

                setCountryOptions(values);
            },
            error: (err: Error) => {
                console.error('Error loading countries:', err);
                setCountryOptions([]);
            },
        });

        return () => {
            sub.unsubscribe();
            job.cancel?.();
        };
    }, []);


    // ==== Table Search ====	

    useEffect(() => {

        setLoadingTable(true);

        setTotalResults(0);

        const filter =
            countryToken === '*'
                ? ''
                : `| search Country="${countryToken.replace(/"/g, '\\"')}"`;


        const tableSearch = SearchJob.create({
            search: `index=bccscm sourcetype=scm:logistics ${filter} | ` +
                'table orderNo, Country, Roast, schedule, shipDate, deliveryDate, Amount, warehouse',
            ...SEARCH_TIME_RANGE,
        });

        setActiveJob(tableSearch);

        return () => {
            tableSearch.cancel?.();
        };

    }, [countryToken]);

    useEffect(() => {
        if (!activeJob) return;

        setLoadingTable(true);

        const progressSub = activeJob.getProgress().subscribe((data: any) => {
            const resultCount = data?.content?.resultCount;
            if (typeof resultCount === 'number') {
                setTotalResults(resultCount);
            }
        });

        const resultsSub = activeJob
            .getResults({
                count: rowsPerPage,
                offset: (currentPage - 1) * rowsPerPage,
            })
            .subscribe({
                next: (rawResults: RawResults) => {
                    const processedFields: SearchResultField[] = (rawResults.fields || []).map((field) =>
                        typeof field === 'string' ? { name: field } : field
                    );

                    const processedResults: SearchResultRow[] = rawResults.results || [];

                    setTableResults({ fields: processedFields, results: processedResults });
                    setLoadingTable(false);
                },
                error: (err: Error) => {
                    console.error('Error fetching results:', err);
                    setTableResults({ fields: [], results: [] });
                    setLoadingTable(false);
                },
            });

        return () => {
            progressSub.unsubscribe();
            resultsSub.unsubscribe();
        };
    }, [activeJob, currentPage, rowsPerPage]);

    const totalPages = Math.max(1, Math.ceil(totalResults / rowsPerPage));


    return (
        <StyledContainer>

            {/* ===== VISUALIZATIONS ===== */}

            <SectionTitle>Inventory</SectionTitle>

            {/* ===== Dropdown Input ===== */}

            <Label>Select a Country:</ Label>
            <Select
                value={countryToken}
                onChange={handleCountryChange}
                style={{ width: 150, marginBottom: 16 }}
            >
                <Select.Option label="All Countries" value="*" />
                {countryOptions.map((c) => (
                    <Select.Option key={c} label={c} value={c} />
                ))}
            </Select>


            <VizRow>
                {/* ===== Table ===== */}
                <VizContainer style={{ flex: 1, minWidth: 0 }}>
                    <Label>Coffee Shipments</Label>
                    {loadingTable ? (
                        <WaitSpinner size="medium" />
                    ) : tableResults.fields.length > 0 ? (
                        <>
                            <Table stripeRows>
                                <Table.Head>
                                    <Table.HeadCell>Order No.</Table.HeadCell>
                                    <Table.HeadCell>Country</Table.HeadCell>
                                    <Table.HeadCell>Roast</Table.HeadCell>
                                    <Table.HeadCell>Schedule</Table.HeadCell>
                                    <Table.HeadCell>Ship Date</Table.HeadCell>
                                    <Table.HeadCell>Delivery Date</Table.HeadCell>
                                    <Table.HeadCell>Amount (kg)</Table.HeadCell>
                                    <Table.HeadCell>Warehouse</Table.HeadCell>

                                </Table.Head>

                                <Table.Body>
                                    {tableResults.results.map((result, rowIndex) => (
                                        <Table.Row key={`row-${rowIndex}`}>
                                            {tableResults.fields.map((field) => (
                                                <Table.Cell key={`cell-${rowIndex}-${field.name}`}>
                                                    {String(result[field.name] ?? 'N/A')}
                                                </Table.Cell>
                                            ))}
                                        </Table.Row>
                                    ))}
                                </Table.Body>
                            </Table>

                            <div style={{ marginTop: 12 }}>
                                <Paginator
                                    current={currentPage}
                                    totalPages={Math.max(1, Math.ceil(totalResults / rowsPerPage))}
                                    onChange={handlePageChange}
                                />
                            </div>
                        </>
                    ) : (
                        <div>No table data available.</div>
                    )}
                </VizContainer>
            </VizRow>


        </StyledContainer>
    );
};

export default Inventory;
